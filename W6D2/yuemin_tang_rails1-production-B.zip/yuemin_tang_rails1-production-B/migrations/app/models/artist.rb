class Artist < ApplicationRecord
  
end
