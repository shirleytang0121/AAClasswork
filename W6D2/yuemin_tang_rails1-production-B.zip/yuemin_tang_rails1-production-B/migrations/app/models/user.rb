class User < ApplicationRecord
  
end
