class Player
    def initialize(name)
        @name=name
        @player_char=''
    end

    def guess
        puts "Enter a character"
        char = gets.chomp.downcase
        if alert_invalid_guess(char)
            return char.downcase
        else
            raise "please try again"
        end
        #@player_char=char
    end


    def alert_invalid_guess(char)
        alphabet=('a'..'z').to_a
        return false if alphabet.include?(char.downcase)
        true
    end
end