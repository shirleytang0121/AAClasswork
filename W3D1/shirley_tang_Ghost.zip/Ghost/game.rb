require_relative "player.rb"
class Game

    def initialize
        @fragment =""
        word = File.readlines("dictionary.txt").map(&:chomp)
        @dictionary = Set.new(word)
        @player_1=Player.new("Shirley")
        @player_1 = Player.new("Mike")

    end


end