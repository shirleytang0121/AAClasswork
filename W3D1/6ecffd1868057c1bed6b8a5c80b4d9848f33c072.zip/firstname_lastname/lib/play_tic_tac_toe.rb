# execute this file to play your game once all specs are completed
# no code needs to be written in this file

require_relative "tic_tac_toe"

TicTacToe.new.play