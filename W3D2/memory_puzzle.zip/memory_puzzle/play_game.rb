require_relative "game"
require_relative "board"
require_relative "card"


game=Game.new(4)
game.play